import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Sparkles, Heart, Sun, Anchor, AlignJustify, Scissors } from "lucide-react"

const services = [
  {
    icon: Sparkles,
    title: "Teeth Cleaning & Scaling",
    description: "Professional cleaning to remove plaque, tartar, and stains for healthier gums and fresher breath.",
  },
  {
    icon: Heart,
    title: "Root Canal Treatment (RCT)",
    description: "Pain-free root canal procedures to save infected teeth and relieve toothache.",
  },
  {
    icon: Sun,
    title: "Teeth Whitening",
    description: "Advanced whitening treatments to give you a brighter, more confident smile.",
  },
  {
    icon: Anchor,
    title: "Dental Implants",
    description: "Permanent tooth replacement solutions that look and feel like natural teeth.",
  },
  {
    icon: AlignJustify,
    title: "Braces & Aligners",
    description: "Orthodontic treatments including traditional braces and clear aligners for perfect alignment.",
  },
  {
    icon: Scissors,
    title: "Tooth Extraction",
    description: "Safe and painless tooth removal procedures with minimal discomfort and quick recovery.",
  },
]

export function ServicesSection() {
  return (
    <section id="services" className="py-16 md:py-24 bg-background">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <span className="inline-block text-primary font-medium text-sm uppercase tracking-wider mb-3">
            Our Services
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            Comprehensive Dental Care
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-pretty">
            From routine check-ups to advanced procedures, we offer a full range of dental 
            services to keep your smile healthy and beautiful.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => (
            <Card 
              key={service.title} 
              className="group hover:shadow-lg transition-shadow duration-300 border-border"
            >
              <CardHeader>
                <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <service.icon className="w-7 h-7 text-primary" />
                </div>
                <h3 className="text-xl font-semibold text-foreground">{service.title}</h3>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{service.description}</p>
              </CardContent>
              <CardFooter>
                <Button variant="outline" size="sm" asChild className="w-full">
                  <a 
                    href={`https://wa.me/919894087923?text=Hi,%20I%20want%20to%20book%20an%20appointment%20for%20${encodeURIComponent(service.title)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Book Now
                  </a>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
