import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight } from "lucide-react"

const transformations = [
  {
    before: "Stained & Yellow Teeth",
    after: "Bright White Smile",
    procedure: "Teeth Whitening",
  },
  {
    before: "Crooked Teeth",
    after: "Perfectly Aligned",
    procedure: "Braces Treatment",
  },
  {
    before: "Missing Tooth",
    after: "Natural Looking Implant",
    procedure: "Dental Implant",
  },
]

export function BeforeAfterSection() {
  return (
    <section className="py-16 md:py-24 bg-secondary">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <span className="inline-block text-primary font-medium text-sm uppercase tracking-wider mb-3">
            Smile Transformations
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            Real Patient Results
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-pretty">
            See the amazing transformations we&apos;ve achieved for our patients. 
            Your dream smile could be next!
          </p>
        </div>

        {/* Transformations Grid */}
        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {transformations.map((item, index) => (
            <Card key={index} className="overflow-hidden border-border">
              <CardContent className="p-6">
                <div className="flex items-center justify-between gap-4 mb-4">
                  {/* Before */}
                  <div className="flex-1 text-center">
                    <div className="w-20 h-20 mx-auto bg-red-100 rounded-full flex items-center justify-center mb-2">
                      <span className="text-2xl">😔</span>
                    </div>
                    <p className="text-sm text-muted-foreground font-medium">Before</p>
                    <p className="text-xs text-muted-foreground">{item.before}</p>
                  </div>
                  
                  {/* Arrow */}
                  <ArrowRight className="w-6 h-6 text-primary shrink-0" />
                  
                  {/* After */}
                  <div className="flex-1 text-center">
                    <div className="w-20 h-20 mx-auto bg-green-100 rounded-full flex items-center justify-center mb-2">
                      <span className="text-2xl">😁</span>
                    </div>
                    <p className="text-sm text-muted-foreground font-medium">After</p>
                    <p className="text-xs text-muted-foreground">{item.after}</p>
                  </div>
                </div>
                
                {/* Procedure badge */}
                <div className="text-center">
                  <span className="inline-block bg-primary/10 text-primary text-sm font-medium px-4 py-2 rounded-full">
                    {item.procedure}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
