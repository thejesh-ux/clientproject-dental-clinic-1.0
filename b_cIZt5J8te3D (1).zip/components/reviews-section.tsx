import { Card, CardContent } from "@/components/ui/card"
import { Star, Quote } from "lucide-react"

const reviews = [
  {
    name: "Ravi K",
    review: "Very professional and painless treatment. Highly recommend!",
    rating: 5,
  },
  {
    name: "Priya S",
    review: "Clean clinic and friendly doctor. Best dental care in Coimbatore.",
    rating: 5,
  },
  {
    name: "Arjun M",
    review: "Affordable and quick service. Got my root canal done smoothly.",
    rating: 5,
  },
  {
    name: "Meena R",
    review: "The staff is very caring and the doctor explains everything clearly. Great experience!",
    rating: 5,
  },
  {
    name: "Karthik V",
    review: "Best dental clinic I have visited. Modern equipment and very hygienic.",
    rating: 5,
  },
  {
    name: "Anitha L",
    review: "My kids love coming here! The doctor is so gentle and patient with children.",
    rating: 5,
  },
]

export function ReviewsSection() {
  return (
    <section id="reviews" className="py-16 md:py-24 bg-background">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <span className="inline-block text-primary font-medium text-sm uppercase tracking-wider mb-3">
            Patient Reviews
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            What Our Patients Say
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-pretty">
            Don&apos;t just take our word for it. Here&apos;s what our happy patients 
            have to say about their experience at Lakshmi Dental Care.
          </p>
        </div>

        {/* Reviews Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {reviews.map((review, index) => (
            <Card 
              key={index} 
              className="relative overflow-hidden border-border hover:shadow-lg transition-shadow duration-300"
            >
              <CardContent className="pt-6">
                {/* Quote icon */}
                <Quote className="absolute top-4 right-4 w-8 h-8 text-primary/10" />
                
                {/* Stars */}
                <div className="flex gap-1 mb-4">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                
                {/* Review text */}
                <p className="text-foreground mb-4 italic">&ldquo;{review.review}&rdquo;</p>
                
                {/* Author */}
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                    <span className="text-primary font-semibold">
                      {review.name.charAt(0)}
                    </span>
                  </div>
                  <span className="font-medium text-foreground">{review.name}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Google Review CTA */}
        <div className="text-center mt-12">
          <a 
            href="https://www.google.com/maps/search/?api=1&query=Lakshmi+Dental+Care+Coimbatore" 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-primary hover:underline font-medium"
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12.48 10.92v3.28h7.84c-.24 1.84-.853 3.187-1.787 4.133-1.147 1.147-2.933 2.4-6.053 2.4-4.827 0-8.6-3.893-8.6-8.72s3.773-8.72 8.6-8.72c2.6 0 4.507 1.027 5.907 2.347l2.307-2.307C18.747 1.44 16.133 0 12.48 0 5.867 0 .307 5.387.307 12s5.56 12 12.173 12c3.573 0 6.267-1.173 8.373-3.36 2.16-2.16 2.84-5.213 2.84-7.667 0-.76-.053-1.467-.173-2.053H12.48z"/>
            </svg>
            See More Reviews on Google
          </a>
        </div>
      </div>
    </section>
  )
}
