"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { MessageCircle, Calendar } from "lucide-react"

export function AppointmentSection() {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    problem: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    const message = `Hi, I want to book a dental appointment.
    
Name: ${formData.name}
Phone: ${formData.phone}
Problem: ${formData.problem || "General consultation"}`

    const whatsappUrl = `https://wa.me/919894087923?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, "_blank")
  }

  return (
    <section id="contact" className="py-16 md:py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
          {/* Left Content */}
          <div className="text-center lg:text-left">
            <span className="inline-block text-primary font-medium text-sm uppercase tracking-wider mb-3">
              Book Appointment
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
              Ready for Your Best Smile?
            </h2>
            <p className="text-muted-foreground mb-8 text-pretty">
              Fill out the form and we&apos;ll connect with you on WhatsApp to confirm your appointment. 
              It&apos;s quick, easy, and convenient!
            </p>
            
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-4 p-4 bg-secondary rounded-xl">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center shrink-0">
                  <Calendar className="w-6 h-6 text-primary" />
                </div>
                <div className="text-left">
                  <h4 className="font-semibold text-foreground">Flexible Scheduling</h4>
                  <p className="text-sm text-muted-foreground">Choose a time that works best for you</p>
                </div>
              </div>
              
              <div className="flex items-center gap-4 p-4 bg-secondary rounded-xl">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center shrink-0">
                  <MessageCircle className="w-6 h-6 text-primary" />
                </div>
                <div className="text-left">
                  <h4 className="font-semibold text-foreground">WhatsApp Confirmation</h4>
                  <p className="text-sm text-muted-foreground">Get instant appointment confirmation</p>
                </div>
              </div>
            </div>
          </div>

          {/* Form */}
          <Card className="border-border shadow-xl">
            <CardHeader>
              <CardTitle className="text-2xl">Book Your Visit</CardTitle>
              <CardDescription>
                Fill in your details and we&apos;ll get back to you shortly
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="flex flex-col gap-4">
                <div className="flex flex-col gap-2">
                  <label htmlFor="name" className="text-sm font-medium text-foreground">
                    Your Name
                  </label>
                  <Input
                    id="name"
                    placeholder="Enter your full name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>
                
                <div className="flex flex-col gap-2">
                  <label htmlFor="phone" className="text-sm font-medium text-foreground">
                    Phone Number
                  </label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="Enter your phone number"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    required
                  />
                </div>
                
                <div className="flex flex-col gap-2">
                  <label htmlFor="problem" className="text-sm font-medium text-foreground">
                    Describe Your Problem (Optional)
                  </label>
                  <Textarea
                    id="problem"
                    placeholder="Tell us about your dental concern..."
                    rows={3}
                    value={formData.problem}
                    onChange={(e) => setFormData({ ...formData, problem: e.target.value })}
                  />
                </div>
                
                <Button type="submit" size="lg" className="w-full gap-2 mt-2">
                  <MessageCircle className="w-5 h-5" />
                  Book via WhatsApp
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
