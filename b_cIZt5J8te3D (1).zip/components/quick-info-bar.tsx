"use client"

import { MapPin, Phone, Clock } from "lucide-react"

function getOpenStatus() {
  const now = new Date()
  const day = now.getDay() // 0 = Sunday
  const hour = now.getHours()
  const minute = now.getMinutes()
  const currentTime = hour + minute / 60

  if (day === 0) {
    // Sunday: 10:30 am – 12:30 pm
    if (currentTime >= 10.5 && currentTime < 12.5) {
      return { isOpen: true, text: "Open Now · Closes 12:30 PM" }
    }
    return { isOpen: false, text: "Closed · Opens Mon 9:30 AM" }
  } else {
    // Monday–Saturday: 9:30 am – 1:30 pm, 4:30 pm – 9:00 pm
    if (currentTime >= 9.5 && currentTime < 13.5) {
      return { isOpen: true, text: "Open Now · Closes 1:30 PM" }
    } else if (currentTime >= 16.5 && currentTime < 21) {
      return { isOpen: true, text: "Open Now · Closes 9:00 PM" }
    } else if (currentTime < 9.5) {
      return { isOpen: false, text: "Closed · Opens 9:30 AM" }
    } else if (currentTime >= 13.5 && currentTime < 16.5) {
      return { isOpen: false, text: "Closed · Opens 4:30 PM" }
    }
    return { isOpen: false, text: "Closed · Opens Tomorrow 9:30 AM" }
  }
}

export function QuickInfoBar() {
  const status = getOpenStatus()

  return (
    <section className="bg-primary text-primary-foreground py-4">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Address */}
          <div className="flex items-center gap-3">
            <MapPin className="w-5 h-5 shrink-0" />
            <span className="text-sm md:text-base text-center md:text-left">
              #12/17, Arangaswamy Nagar, Airport Rd, Coimbatore, Tamil Nadu 641014
            </span>
          </div>

          {/* Phone */}
          <a 
            href="tel:9894087923" 
            className="flex items-center gap-3 hover:opacity-80 transition-opacity"
          >
            <Phone className="w-5 h-5 shrink-0" />
            <span className="text-sm md:text-base font-medium">9894087923</span>
          </a>

          {/* Open Status */}
          <div className="flex items-center gap-3">
            <Clock className="w-5 h-5 shrink-0" />
            <div className="flex items-center gap-2">
              <span 
                className={`w-2 h-2 rounded-full ${status.isOpen ? 'bg-green-400' : 'bg-red-400'}`}
              />
              <span className="text-sm md:text-base">{status.text}</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
