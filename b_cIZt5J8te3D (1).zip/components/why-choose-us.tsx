import { UserCheck, Stethoscope, Wallet, Cpu, ShieldCheck } from "lucide-react"

const features = [
  {
    icon: UserCheck,
    title: "Experienced Dentist",
    description: "Our skilled dental professionals bring years of expertise to every procedure.",
  },
  {
    icon: Stethoscope,
    title: "Pain-Free Procedures",
    description: "Advanced techniques and anesthesia ensure comfortable, anxiety-free treatments.",
  },
  {
    icon: Wallet,
    title: "Affordable Pricing",
    description: "Quality dental care at competitive prices with flexible payment options.",
  },
  {
    icon: Cpu,
    title: "Advanced Equipment",
    description: "State-of-the-art technology for accurate diagnosis and effective treatments.",
  },
  {
    icon: ShieldCheck,
    title: "Hygienic & Sterile Environment",
    description: "Strict sterilization protocols ensure your safety at every visit.",
  },
]

export function WhyChooseUs() {
  return (
    <section id="why-us" className="py-16 md:py-24 bg-secondary">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <span className="inline-block text-primary font-medium text-sm uppercase tracking-wider mb-3">
            Why Choose Us
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            Your Trust, Our Commitment
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-pretty">
            We combine expertise, technology, and compassionate care to deliver 
            the best dental experience in Coimbatore.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {features.map((feature, index) => (
            <div 
              key={feature.title}
              className={`flex flex-col items-center text-center p-6 ${
                index === features.length - 1 && features.length % 3 !== 0 
                  ? 'lg:col-span-1 lg:col-start-2' 
                  : ''
              }`}
            >
              <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center mb-4 shadow-lg">
                <feature.icon className="w-8 h-8 text-primary-foreground" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">{feature.title}</h3>
              <p className="text-muted-foreground text-sm">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
