import Link from "next/link"
import { Phone, MapPin, Clock, MessageCircle } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-foreground text-background">
      <div className="container mx-auto px-4 py-12 md:py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="lg:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-lg">L</span>
              </div>
              <div className="flex flex-col">
                <span className="font-semibold text-lg leading-tight">Lakshmi</span>
                <span className="text-xs opacity-70 -mt-1">Dental Care</span>
              </div>
            </Link>
            <p className="text-sm opacity-80 mb-4">
              Advanced dental care for a confident smile. Pain-free treatments with modern 
              equipment in Coimbatore.
            </p>
            <a 
              href="https://wa.me/919894087923?text=Hi,%20I%20want%20to%20book%20a%20dental%20appointment" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-green-700 transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              Chat on WhatsApp
            </a>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Quick Links</h4>
            <nav className="flex flex-col gap-2">
              <Link href="#services" className="text-sm opacity-80 hover:opacity-100 transition-opacity">
                Our Services
              </Link>
              <Link href="#why-us" className="text-sm opacity-80 hover:opacity-100 transition-opacity">
                Why Choose Us
              </Link>
              <Link href="#reviews" className="text-sm opacity-80 hover:opacity-100 transition-opacity">
                Patient Reviews
              </Link>
              <Link href="#contact" className="text-sm opacity-80 hover:opacity-100 transition-opacity">
                Book Appointment
              </Link>
            </nav>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Contact Us</h4>
            <div className="flex flex-col gap-4">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 shrink-0 mt-0.5 opacity-80" />
                <p className="text-sm opacity-80">
                  #12/17, Arangaswamy Nagar, First Floor, Civil Aerodrome Post, 
                  Airport Rd, Coimbatore, Tamil Nadu 641014
                </p>
              </div>
              <a href="tel:9894087923" className="flex items-center gap-3 hover:opacity-100 transition-opacity">
                <Phone className="w-5 h-5 shrink-0 opacity-80" />
                <span className="text-sm opacity-80">9894087923</span>
              </a>
            </div>
          </div>

          {/* Working Hours */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Working Hours</h4>
            <div className="flex flex-col gap-3">
              <div className="flex items-start gap-3">
                <Clock className="w-5 h-5 shrink-0 mt-0.5 opacity-80" />
                <div className="text-sm opacity-80">
                  <p className="font-medium mb-1">Sunday</p>
                  <p>10:30 AM – 12:30 PM</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Clock className="w-5 h-5 shrink-0 mt-0.5 opacity-80" />
                <div className="text-sm opacity-80">
                  <p className="font-medium mb-1">Monday – Saturday</p>
                  <p>9:30 AM – 1:30 PM</p>
                  <p>4:30 PM – 9:00 PM</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-background/20 mt-12 pt-8 text-center">
          <p className="text-sm opacity-70">
            © {new Date().getFullYear()} Lakshmi Dental Care. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}
