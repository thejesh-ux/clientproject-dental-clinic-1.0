import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { QuickInfoBar } from "@/components/quick-info-bar"
import { ServicesSection } from "@/components/services-section"
import { WhyChooseUs } from "@/components/why-choose-us"
import { ReviewsSection } from "@/components/reviews-section"
import { BeforeAfterSection } from "@/components/before-after-section"
import { AppointmentSection } from "@/components/appointment-section"
import { MapSection } from "@/components/map-section"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Header />
      <HeroSection />
      <QuickInfoBar />
      <ServicesSection />
      <WhyChooseUs />
      <ReviewsSection />
      <BeforeAfterSection />
      <AppointmentSection />
      <MapSection />
      <Footer />
    </main>
  )
}
